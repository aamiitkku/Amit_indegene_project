let burger = document.getElementById("burger");
let cross = document.getElementById("cross");
let nav = document.getElementById("nav");

const showMenu = ()=>{
    nav.classList.remove("hidden");
    burger.classList.add("hidden");
    cross.classList.remove("hidden");

}

const hideMenu = ()=>{
    nav.classList.add("hidden");
    cross.classList.add("hidden");
    burger.classList.remove("hidden");
}

burger.addEventListener("click",showMenu)
cross.addEventListener("click",hideMenu)